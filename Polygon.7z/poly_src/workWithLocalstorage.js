const additionBtn = document.getElementById('add');
const delBtn = document.getElementById('rem');
const list = document.getElementById('list');
const inputValue = document.getElementById('taskText').value;


// Научить приложение хранить данные !!!!
let tasks = [];

 

additionBtn.onclick = function(inputValue) {
 
    if (inputValue === '') {
        console.log('пустое значение');
        return false;
    } else {
        tasks.push(inputValue);
        rederTask(inputValue);
    }


}; 



function rederTask() {
    let newTaskInfo = `<li
                            class="list__item":> ${inputValue} 
                            <button class="task_delBtn" >Удалить</button>    
                           <li/>`;
    let SavedItem = list.insertAdjacentHTML('beforeend', newTaskInfo); 
    return SavedItem;
}

 console.log(tasks);

 



list.onclick = function(e) {
    const btn = e.target.closest('.task_delBtn');
    if (!btn) {
      return;
    }
    
    btn.parentElement.remove();
}